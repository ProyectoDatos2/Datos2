/**
 * @file ModemDriver.h
 * @author Antonino Gratton (antonino.gratton@gmail.com)
 * @brief El presente driver desarrollado para el modem Goouuu tech iot-ga6-b, controla sus funciones mediante comandos y 
 * posee métodos para recibir y enviar datos desde y al servidor especificado a través de protocolo TCP/IP.
 * @version 0.1
 * @date 2023-03-28
 *
 * @copyright OMIXOM S.R.L. (c) 2023
 *
 */

#ifndef MODEM_DRIVER_H
#define MODEM_DRIVER_H

#include <Arduino.h>
#include "UartDriver.h"

#define END_CHAR (char)0x1A                 // Caracter de final de mensaje.
#define MODEM_SUPPLY_PIN 2                  // Pin de arduino que controla la alimentación del modem.
#define ERROR_COUNT_RESET 3                 // Cantidad de errores a partir de los que se envía un reset al modem.
#define MODEM_OFF_WAIT_TIME_MS 3000         // Tiempo de apagado del modem.
#define MODEM_RESET_WAIT_TIME_MS 10000      // Tiempo de espera del modem, luego de su encendido.
#define SERVER_RESP_SIZE 2*MAX_RX_DATA_SIZE // Tamaño del buffer para contener la respuesta final del servidor.

#define MODEM_OFF digitalWrite(MODEM_SUPPLY_PIN, HIGH);
#define MODEM_ON digitalWrite(MODEM_SUPPLY_PIN, LOW);

// Respuestas esperadas del modem.
#define __OK__ "OK\r\n"
#define __SHUT_OK__ "\r\nSHUT OK\r\n"
#define __CONNECT_OK__ "\r\nCONNECT OK\r\n"
#define __PROMPT__ "\r\n>"
#define __SEND_OK__ "\r\nSEND OK\r\n"
#define __CLOSE_OK__ "\r\nCLOSE OK\r\n"

class ModemDriver : private UartDriver {
  public:
    ModemDriver(SoftwareSerial* port, const uint32_t& baudrate); // Los argumentos son el handler del puerto serie y el baudrate.

    /**
     * @brief Inicializa el driver del modem y establece la máquina en el primer estado.
     * 
     */
    void init();

    /**
     * @brief Lleva el control de la máquina de estados. Se encarga de llamar a las otras funciones y evolucionar la máquina cuando,
     * las condiciones están dadas. Se debe llamar de forma permanente en el bucle principal para que se actualicen los estados.
     * 
     */
    void update();

    /**
     * @brief Sube una cadena de caracteres al servidor
     *
     * @param data Cadena de caracteres a subir.
     */
    void upload(const char* data);

    /**
     * @brief Determina si existe una respuesta del servidor, disponible.
     * 
     * @return true si existe una respuesta.
     * @return false si no existe ninguna respuesta.
     */
    bool available();

    /**
     * @brief Obtiene la respuesta del servidor, ante la subida de datos.
     *
     * @param buffer Vector de caracteres donde se almacenará la respuesta. Debe tener tamaño MAX_RX_DATA_SIZE (ver UartDriver.h)
     * @return Error::Code código de error.
     */
    Error::Code getResponse(char* buffer);

    /**
     * @brief Indica si una muestra se terminó de subir.
     * 
     * @return true si la muestra se subió.
     * @return false si está subiendo una muestra.
     */
    bool uploaded();

    ~ModemDriver() {}

  private:
    // Estados de la máquina.
    enum States {
        IDLE,
        checkState,
        echoOffState,
        funcLevelState,
        attachPDSState,
        singleIPConnState,
        setAPNState,
        GPRSUpState,
        getIpState,
        startTCPConnState,
        TCPSendState,
        messageState,
        closeTCPConnState,
        closePDPState
    } __generalState;

    uint8_t __errorCount; // Contador de errores. Cuando llega a ERROR_COUNT_RESET, reinicia el modem.
    char __txData[MAX_TX_DATA_SIZE] = ""; // Buffer de datos de salida.
    char __rxData[MAX_RX_DATA_SIZE] = ""; // Buffer de datos de entrada.
    Error::Code __rxErrorCode;            // Handler para los errores del driver de UART.
    bool __waitingFlag; // Flag para detener la máquina de estados (si está en alto).
    bool __startupFlag; // Flag para indicar que el programa comenzó a correr y debe inicializarse el modem.
    bool __initialized; // Flag para indicar que el modem ya se inicializó.
    bool __sending;     // Flag para indicar que el modem está envíando datos.

    // Variables para contener el tiempo de ejecución actual, utilizado en delays no bloqueantes.
    uint32_t __currT = 0;
    uint32_t __mdmRstPrevT = 0; 
    bool __prevTimeUpdateFlag;  // Flag para indicar que se debe actualizar __mdmRstPrevT con el epoch actual y así comenzar a contar para un delay no bloqueante.

    /**
     * @brief Función que introduce una demora en el inicio de la máquina de estados al principio de la ejecución, para
     * permitirle al modem encenderse correctamente.
     * 
     */
    void __startupWaiting();
    
    /**
     * @brief Función que se ejecuta con cada ciclo de la máquina de estados, que lleva la cuenta de los errores y chequea si hace falta resetear el modem.
     * 
     */
    void __checkModemRST();
    
    /**
     * @brief Este método obtiene la respuesta del driver de UART, al comando previamente enviado y contrasta con una respuesta esperada. Si todo es correcto,
     * evoluciona la máquina al siguiente estado.
     * 
     * @param nextState Estado siguiente si todo es correcto.
     * @param okStr Cadena de caracteres con la respuesta esperada del modem. (Ej.: __OK__, __SHUT__OK__, etc.).
     */
    void __getResp_nextState(const enum States& nextState, const char* okStr);

    // Cadenas de caracteres, constantes, con los comandos a enviar al modem.
    static constexpr const char *__AT = "AT\r";
    static constexpr const char *__ATEchoOff = "ATE0\r\n";
    static constexpr const char *__ATFuncLevel = "AT+CFUN=1\r\n";
    static constexpr const char *__ATClosePDP = "AT+CIPSHUT\r\n";
    static constexpr const char *__ATSingleIPConn = "AT+CIPMUX=0\r\n";
    static constexpr const char *__ATAttachPDS = "AT+CGATT=1\r\n";
    static constexpr const char *__ATSetAPN = "AT+CSTT=\"internet.personal.com\"\r";
    //static constexpr const char *__ATSetAPN = "AT+CSTT=\"igprs.claro.com.ar\"\r";
    static constexpr const char *__ATGPRSUp = "AT+CIICR\r\n";
    static constexpr const char *__ATGetIP = "AT+CIFSR\r\n";
    static constexpr const char *__ATStartTCPConn = "AT+CIPSTART=\"TCP\",\"new.omixom.com\",4545\r\n";
    static constexpr const char *__ATTCPSend = "AT+CIPSEND\r\n";
    static constexpr const char *__ATCloseTCPConn = "AT+CIPCLOSE\r\n";
};

#endif
