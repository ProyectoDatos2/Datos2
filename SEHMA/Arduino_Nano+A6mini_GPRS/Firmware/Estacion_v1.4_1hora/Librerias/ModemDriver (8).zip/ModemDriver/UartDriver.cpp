/**
 * @file UartDriver.h
 * @author Antonino Gratton (antonino.gratton@gmail.com)
 * @brief Este driver controla de forma directa la UART, se utiliza como clase base de la clase ModemDriver. Se 
 * encarga de enviar comandos por UART al modem, esperar respuesta y recibirlas.
 * @version 0.1
 * @date 2023-03-28
 *
 * @copyright OMIXOM S.R.L. (c) 2023
 *
 */

#include "UartDriver.h"

UartDriver::UartDriver(SoftwareSerial* port, const uint32_t &baudrate): __port(port) { // Se inicializa en el estado IDLE y con error indefinido.
    __transactStatus = CmdTransactionStatus::IDLE;
    __errorStatus = Error::Code::UNDEFINED;
    __baudrate = baudrate;
    __port->begin(__baudrate);
}

void UartDriver::send(const char* buffer, bool addEndMessageChar, const uint16_t& respLength) {
    __endMessageCharFlag = addEndMessageChar;
    __respLength = respLength;
    while(__port->available() && __transactStatus == CmdTransactionStatus::IDLE)
        __port->read(); // Si había algo en el buffer de recepción, lo vacío antes.

    if (__dataRXTX[0] == 0 && __transactStatus == CmdTransactionStatus::IDLE) { // Si el buffer __dataRXTX estaba vacío y el estado es IDLE, se copia el contenido de buffer.
        strcpy(__dataRXTX, buffer);
        SERIAL_DEBUG.print(F("Data recibida por UartDriver: "));
        SERIAL_DEBUG.println(__dataRXTX);
    }
}

Error::Code UartDriver::receive(char* buffer, const char* matchOk) {
    if(__transactStatus == CmdTransactionStatus::RESP_READY) { // Si la respuesta está lista, sin importar si es válida o inválida
        if(matchOk == nullptr) {    // Si no se especificó una respuesta esperada, es porque no importa lo que responda.
            if(buffer[0] == 0) {    // Si el vector pasado como argumento está vacío, copia el contenido del buffer __dataRXTX en él.
                for(uint8_t i = 0; i < MAX_RX_DATA_SIZE; i++) {
                    buffer[i] = __dataRXTX[i];
                }
            }
            memset(__dataRXTX, 0, sizeof(__dataRXTX)); // Vacía el buffer.
            return Error::Code::OK;                    // Retorna error OK.
        }

        else if(strstr(__dataRXTX, matchOk) != NULL) {  // Chequea que la respuesta, al menos contenga la respuesta esperada.    
            memset(__dataRXTX, 0, sizeof(__dataRXTX));  // En ese caso vacía el buffer y responde error OK porque no interesa la respuesta, si no que haya salido bien.
            return Error::Code::OK;
        }

        else if(strstr(__dataRXTX, "ERROR") != NULL) {  // Si tiene la palabra ERROR, borra el buffer y retorna código ERROR.
            memset(__dataRXTX, 0, sizeof(__dataRXTX));
            return Error::Code::ERROR;
        }

        else if(__errorStatus == Error::Code::TIMEOUT) {
            memset(__dataRXTX, 0, sizeof(__dataRXTX));
            return Error::Code::TIMEOUT;
        }
        
        else {
            memset(__dataRXTX, 0, sizeof(__dataRXTX)); // Si no tiene nada, sigue esperando respuesta.
            __transactStatus = CmdTransactionStatus::WAITING_RESP;
            return Error::Code::UNDEFINED;
        }
    }

    else
        return __errorStatus;
}

Error::Code UartDriver::errorStatus() {
    return __errorStatus;
}

uint8_t UartDriver::comStatus() {
    return __transactStatus;
}

void UartDriver::__timeoutCheck() { // Si se cumple el tiempo UART_RX_TIMEOUT_MS esperando respuesta, pasa a RESP_READY pero retorna error de timeout.
    if((__currT - __timeoutPrevT) >= UART_RX_TIMEOUT_MS) {
        __timeoutPrevT = __currT;
        __dataReceivedFlag = false;
        __transactStatus = CmdTransactionStatus::RESP_READY;
        __errorStatus = Error::Code::TIMEOUT;
    }
}

void UartDriver::__portOpen() {
    __port->begin(__baudrate);
}

void UartDriver::__portClose() {
    __port->end();
}

void UartDriver::__uartDriverReset() {
    __transactStatus = CmdTransactionStatus::IDLE;
    __errorStatus = Error::Code::UNDEFINED;

    __currT = 0;
    __timeoutPrevT = 0;
    __rxCharPrevT = 0;

    __dataReceivedFlag = false;
    __timeoutExecFlag = false;
    __endMessageCharFlag = false;

    __respLength = 0;

    memset(__dataRXTX, 0, sizeof(__dataRXTX)); // Se borra el buffer.
}

void UartDriver::update() {
    switch(__transactStatus) {
        case CmdTransactionStatus::IDLE:
            __errorStatus = Error::Code::UNDEFINED;
            SERIAL_DEBUG.println(F("ESTADO IDLE"));
            if(__dataRXTX[0] != 0) {    // Si se carga algo en el buffer, pasa a estado SENDING.
                __transactStatus = CmdTransactionStatus::SENDING;
            }
            break;
        
        case CmdTransactionStatus::SENDING:
            __errorStatus = Error::Code::UNDEFINED;
            SERIAL_DEBUG.println(F("ESTADO SENDING"));
            __port->print(__dataRXTX); // Envía el mensaje al modem.
            if(__endMessageCharFlag) { // Si se especificó que se tiene que agregar el caracter de final de mensaje, lo agrega.
                __port->print((char)0x1A);
                __port->println("\r");
            }
            memset(__dataRXTX, 0, sizeof(__dataRXTX)); // Se borra el buffer.
            __endMessageCharFlag = false;
            __timeoutPrevT = millis(); // Se actualiza el tiempo anterior del temporizador de timeout.
            __transactStatus = CmdTransactionStatus::WAITING_RESP; // Se pasa directo al estado WAITING_RESP.
            break;
        
        case CmdTransactionStatus::WAITING_RESP:
            SERIAL_DEBUG.println(F("ESTADO WAITING_RESP"));
            __currT = millis();
            __errorStatus = Error::Code::UNDEFINED;

            if(!__timeoutExecFlag) { // Actualiza el tiempo anterior del contador de timeout.
                __timeoutPrevT = __currT;
                __timeoutExecFlag = true; // Solo una vez por comando.
            }

            if(__port->available()) { // Si hay algún dato disponible.
                if(!__dataReceivedFlag)  {// Se actualiza el tiempo anterior del delay no bloqueante que espera a que entren todos los caracteres al buffer del puerto serie.
                    __rxCharPrevT = __currT;
                    __dataReceivedFlag = true; // Solo una vez por comando.
                }

                if(__currT - __rxCharPrevT >= UART_CHAR_RX_TIME) { // Pasado el tiempo UART_CHAR_RX_TIME se reciben los datos.

                    uint16_t incommingSize = __port->available();

                    if(__respLength != 0 && incommingSize < __respLength) ; // Si se especificó una longitud de respuesta, y lo que llegó al puerto es de longitud menor a la especificada, no hace nada.

                    else { // Si se recibe el dato
                        __errorStatus = Error::Code::OK;    // Primeramente se lo toma como OK

                        for(uint8_t i = 0; i < incommingSize; i++) {
                            if((incommingSize > MAX_TX_DATA_SIZE - 1) && __errorStatus != Error::Code::BUFFER_OVERFLOW) { // Se verifica que no haya overflow del buffer como entrada.
                                __errorStatus = Error::Code::BUFFER_OVERFLOW;
                            }

                            if(__errorStatus == Error::Code::BUFFER_OVERFLOW) {
                                __port->read(); // Si existe overflow, se lee indefinidamente el puerto hasta que se vacíe.
                            }

                            else {
                                __dataRXTX[i] = __port->read(); // Si sale todo OK, almacena la respuesta en el buffer.
                            }
                        }

                        if(__errorStatus == Error::Code::OK) { // Si al final de todo, salió bien, le agrega el caracter nulo al final de la cadena y pasa al estado RESP_READY.
                            __dataRXTX[incommingSize] = 0; 
                            __transactStatus = CmdTransactionStatus::RESP_READY;
                        }
                        __timeoutPrevT = __currT;
                        __rxCharPrevT = __currT;
                        __dataReceivedFlag = false;
                    }
                    __timeoutExecFlag = false;
                }
            }

            __timeoutCheck(); // Control de timeout.

            break;
        
        case CmdTransactionStatus::RESP_READY:
            SERIAL_DEBUG.println(F("ESTADO RESP_READY"));
            if(__dataRXTX[0] == 0) { // Si se vacía el buffer (porque ya se leyó), vuelve al estado IDLE.
                __transactStatus = CmdTransactionStatus::IDLE;
            }
            break;
        
        default:
            break;
    }
}