/**
 * @file ModemDriver.cpp
 * @author Antonino Gratton (antonino.gratton@gmail.com)
 * @brief El presente driver desarrollado para el modem Goouuu tech iot-ga6-b, controla sus funciones mediante comandos y 
 * posee métodos para recibir y enviar datos desde y al servidor especificado a través de protocolo TCP/IP.
 * @version 0.1
 * @date 2023-03-28
 *
 * @copyright OMIXOM S.R.L. (c) 2023
 *
 */

#include "ModemDriver.h"

ModemDriver::ModemDriver(SoftwareSerial* port, const uint32_t& baudrate) : UartDriver(port, baudrate) {
    pinMode(MODEM_SUPPLY_PIN, OUTPUT);      // Se inicializa el pin que controla la alimentación del modem como salida.
    MODEM_ON                                // Se enciende el modem.
}

void ModemDriver::init() {
    UartDriver::__uartDriverReset();
    __generalState = States::echoOffState;  // El primer estado es el echoOffState.
    __startupFlag = true;                   // Se indica que el modem está iniciando y se debe esperar un periodo de tiempo antes de poner a correr la máquina de estados.

    __rxErrorCode = Error::Code::UNDEFINED; // Se inicializa con un error indefinido.
    __waitingFlag = false;                  // La máquina de estados correrá.
    __prevTimeUpdateFlag = true;            // En el caso de que sea necesario resetear el modem, el tiempo anterior del delay no bloqueante deberá ser actualizado primero.
    __initialized = false;                  // El modem no está inicializado aún.
    __sending = false;                      // Aún no se envió ningún dato.
    __errorCount = 0;
}

void ModemDriver::upload(const char* data) {
    SERIAL_DEBUG.print(F("__sending: "));
    SERIAL_DEBUG.println(__sending);
    SERIAL_DEBUG.print(F("data: "));
    SERIAL_DEBUG.println(data);
    if(!__sending) { // Al intentar subir, si no se está enviando nada, copia el argumento de la función al buffer de salida y establece el flag que indica que se está enviando.
        SERIAL_DEBUG.println(F("ENVIANDO..."));
        strcpy(__txData, data);
        __sending = true;
    }
}

bool ModemDriver::uploaded() {
    return !__sending; // Si no se está enviando nada, ya se subió.
}

bool ModemDriver::available() { // Si el buffer de entrada tiene o no datos, indicará si hay o no elementos disponibles para leer.
    if(__rxData[0] != 0) {
        return true;
    }

    return false;
}

Error::Code ModemDriver::getResponse(char* buffer) {
    if(ModemDriver::available()) { // Si existen elementos en el buffer de entrada.
        for(uint16_t i = 13; i < MAX_RX_DATA_SIZE; i++) { // El 13 es porque ignoro los primeros 13 caracteres que son el SEND OK con los CR y los LF, de la respuesta del modem + la del servidor.
            if(__rxData[i] == (char)0x0D && __rxData[i+1] == (char)0x0A) { // También ignoro los últimos 2 caracteres que son el CR y LF.
                break;
            }
            sprintf((char*)buffer + (2*(i-13)), (const char*)"%02X", __rxData[i]); // Copio los datos del buffer de entrada convirtiendo el ascii a hexa y a su vez a una cadena de caracteres.
        }
		SERIAL_DEBUG.print(F("Respuesta Servidor: "));
		SERIAL_DEBUG.println(__rxData);
        memset(__rxData, 0, sizeof(__rxData)); // Finalmente vacío el buffer de entrada.
    }

    return __rxErrorCode;
}

void ModemDriver::update() {
    
    UartDriver::update(); // Actualizo la máquina de estados del driver de la UART.
    __startupWaiting(); // Verifico si hace falta esperar un tiempo antes de iniciar la máquina de estados.

    __checkModemRST(); // Chequeo las condiciones que podrían disparar un reset en el modem.

    if(!__waitingFlag) { // Si no hay que esperar, inicio la máquina de estados.
        SERIAL_DEBUG.print(F("Estado general: "));
        SERIAL_DEBUG.println(__generalState);
        SERIAL_DEBUG.print(F("Error State: "));
        SERIAL_DEBUG.println(UartDriver::errorStatus());
        switch(__generalState) {
            case States::IDLE:
                SERIAL_DEBUG.print(F("__txData: "));
                SERIAL_DEBUG.println(__txData);
                SERIAL_DEBUG.print(F("__initialized: "));
                SERIAL_DEBUG.println(__initialized);
                if(__txData[0] != 0 && __initialized) { // Si el buffer de salida tiene un dato para enviar y el modem ya está inicializado, paso al estado setAPN.
                    __generalState = States::setAPNState;
                }
                break;

            case States::echoOffState:
                UartDriver::send(__ATEchoOff); // Envía el comando al modem a través del driver de uart.
                SERIAL_DEBUG.println(F("echoOffState"));
                __getResp_nextState(States::funcLevelState, __OK__); // Verifica que llegue la respuesta y que sea __OK__, en ese caso, pasa al estado funcLevel.

				break;
            
            case States::funcLevelState:
                UartDriver::send(__ATFuncLevel);
                SERIAL_DEBUG.println(F("funcLevelState"));
                __getResp_nextState(States::attachPDSState, __OK__);

                break;
            
            case States::attachPDSState:
                UartDriver::send(__ATAttachPDS);
                SERIAL_DEBUG.println(F("attachPDSState"));
                __getResp_nextState(States::singleIPConnState, __OK__);
                break;

            case States::singleIPConnState:
                UartDriver::send(__ATSingleIPConn);
                SERIAL_DEBUG.println(F("singleIPConnState"));
                __initialized = true; // Llegado este punto, indica que ya se inicializó el modem.
                __getResp_nextState(States::IDLE, __OK__);
                break;            

            case States::setAPNState:
                UartDriver::send(__ATSetAPN);
                SERIAL_DEBUG.println(F("setAPNState"));
                __getResp_nextState(States::GPRSUpState, __OK__);
                break;

            case States::GPRSUpState:
                UartDriver::send(__ATGPRSUp);
                SERIAL_DEBUG.println(F("GPRSUpState"));
                __getResp_nextState(States::getIpState, __OK__);
                break;
            
            case States::getIpState:
                UartDriver::send(__ATGetIP);
                SERIAL_DEBUG.println(F("getIpState"));
                __getResp_nextState(States::startTCPConnState, "1");
                break;
            
            case States::startTCPConnState:
                UartDriver::send(__ATStartTCPConn);
                SERIAL_DEBUG.println(F("startTCPConnState"));
                __getResp_nextState(States::TCPSendState, __CONNECT_OK__);
                break;
            
            case States::TCPSendState:
                UartDriver::send(__ATTCPSend);
                SERIAL_DEBUG.println(F("TCPSendState"));
                __getResp_nextState(States::messageState, __PROMPT__);
                break;
            
            case States::messageState:
                UartDriver::send(__txData, true, 13); // Envía al modem el dato que se quiere subir al servidor, se indica que se debe agregar el caracter de final de mensaje y se especifica la longitud mínima de la respuesta esperada.
                SERIAL_DEBUG.println(F("messageState"));
                __getResp_nextState(States::closeTCPConnState, nullptr); // Se especifica nullptr como respuesta lo que es interpretado como que no tiene importancia la respuesta, solo la longitud especificada anteriormente.
                break;
            
            case States::closeTCPConnState:
                UartDriver::send(__ATCloseTCPConn);
                SERIAL_DEBUG.println(F("closeTCPConnState"));
                __getResp_nextState(States::closePDPState, __CLOSE_OK__);
                break;
            

            case States::closePDPState:
                SERIAL_DEBUG.println(F("closePDPState"));
                UartDriver::send(__ATClosePDP);
                
                SERIAL_DEBUG.print(F("__sending: "));
                SERIAL_DEBUG.println(__sending);
                SERIAL_DEBUG.print(F("__initialized: "));
                SERIAL_DEBUG.println(__initialized);
                __getResp_nextState(States::IDLE, __SHUT_OK__);

                if(__generalState == States::IDLE && __sending) { // Si ya cambió de estado a IDLE, se borra el buffer de salida y se inidica que no se está enviando ningún dato.
                    memset(__txData, 0, sizeof(__txData));
                    __sending = false;
                }

                break;

            default:
                break;
        }
    }
}

void ModemDriver::__getResp_nextState(const enum States& nextState, const char* okStr) {
    if(UartDriver::comStatus() == CmdTransactionStatus::RESP_READY) { // Si la respuesta del modem al comando ya está disponible
        __rxErrorCode = UartDriver::receive(__rxData, okStr); // Se recibe la respuesta en el buffer de entrada y se pasa la cadena de caracteres con la que la respuesta debe coincidir. Retorna el código de error.

        if(__rxErrorCode == Error::Code::OK) { // Si el código de eeror es OK, se avanza al siguiente estado, se pone a 0 el contador de errores y se establece el estado de error en indefinido.
            __generalState = nextState;
            __rxErrorCode = Error::Code::UNDEFINED;
            __errorCount = 0;
        }
        // Por el contrario si existe algún tipo de error
        else if (__rxErrorCode == Error::Code::ERROR || __rxErrorCode == Error::Code::BUFFER_OVERFLOW || __rxErrorCode == Error::Code::TIMEOUT) {
            __errorCount++; // Incrementa el contador de errores.
            SERIAL_DEBUG.print(F("[MODEM][ERROR][CODE]: "));
            SERIAL_DEBUG.println(__rxErrorCode);
            SERIAL_DEBUG.print(F("[MODEM][ERROR][COUNT]: "));
            SERIAL_DEBUG.print(__errorCount);
            SERIAL_DEBUG.print(F("/"));
            SERIAL_DEBUG.println(ERROR_COUNT_RESET);
        }
    }
}

void ModemDriver::__startupWaiting() {
    __currT = millis();

    if(__startupFlag) // Si al inicio se debe esperar a que el modem se encienda, se detiene la máquina de estados.
        __waitingFlag = true;

    if(__currT - __mdmRstPrevT >= MODEM_RESET_WAIT_TIME_MS && __startupFlag) { // Pasado el tiempo MODEM_RESET_WAIT_TIME_MS se pone en bajo el flag que indica que se debe esperar, y se desbloquea la máquina de estados.
        __mdmRstPrevT = __currT;
        __startupFlag = false;
        __waitingFlag = false;
    }
}

void ModemDriver::__checkModemRST() {
    if(__errorCount >= ERROR_COUNT_RESET) { // Si la cuenta de errores llegó a ERROR_COUNT_RESET
        if(__prevTimeUpdateFlag) {          // Flag utilizado para indicar que se debe actualizar el tiempo anterior para comenzar a contar tiempo a partir de este momento
            MODEM_OFF                       // Apago el modem.
            SERIAL_DEBUG.println(F("APAGA EL MODEM"));
            __waitingFlag = true;           // Detengo la máquina de estados.
            __mdmRstPrevT = millis();       // Actualizo el tiempo anterior para comenzar a contar desde ahora.
            __prevTimeUpdateFlag = false;   // En los próximos ciclos, mientras se esté en el proceso de reseteo, no actualizo el tiempo anterior. Sigo contando.
            UartDriver::__portClose();      // Cierro el puerto serie con el modem.
        }

        __currT = millis();
        if(__currT - __mdmRstPrevT >= MODEM_OFF_WAIT_TIME_MS) { // Cumplido el tiempo MODEM_OFF_WAIT_TIME_MS enciendo nuevamente el modem.
            SERIAL_DEBUG.println(F("ENCIENDE EL MODEM"));
            MODEM_ON
            UartDriver::__portOpen();           // Abro el puerto serie con el modem.
            UartDriver::__uartDriverReset();    // Reseteo todas las variables del driver de uart.
        }

        /* Cumplido el tiempo de apagado mas el tiempo de encendido del modem, se reinician las variables, se pasa al estado echoOff, se borra el buffer de salida,
         se pone la cuenta de errores a 0, se marca el estado de error en indefinido y se desbloquea la máquina de estados.
         */
        if(__currT - __mdmRstPrevT >= MODEM_RESET_WAIT_TIME_MS + MODEM_OFF_WAIT_TIME_MS) {
            __mdmRstPrevT = __currT;
            __prevTimeUpdateFlag = true;
            __errorCount = 0;
            __waitingFlag = false;
            __initialized = false;
            __sending = false;
            __rxErrorCode == Error::Code::UNDEFINED;
            // memset(__txData, 0, sizeof(__txData));
            __generalState = States::echoOffState;
        }
    }
}
