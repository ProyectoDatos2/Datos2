#ifndef ERROR_H
#define ERROR_H

class Error {
  public:
    enum Code {
        UNDEFINED = -1,
        OK = 0,
        ERROR = 1,
        TIMEOUT = 2,
        BUFFER_OVERFLOW = 3
    };
};

#endif