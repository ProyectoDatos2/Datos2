/**
 * @file UartDriver.h
 * @author Antonino Gratton (antonino.gratton@gmail.com)
 * @brief Este driver controla de forma directa la UART, se utiliza como clase base de la clase ModemDriver. Se
 * encarga de enviar comandos por UART al modem, esperar respuesta y recibirlas.
 * @version 0.1
 * @date 2023-03-28
 *
 * @copyright OMIXOM S.R.L. (c) 2023
 *
 */

#ifndef UART_DRIVER_H
#define UART_DRIVER_H

#include <Arduino.h>
#include <SoftwareSerial.h>
#include "Error.h"

#define UART_RX_TIMEOUT_MS 60000 // Tiempo de espera máximo en ms para respuesta del modem.
#define MAX_TX_FRAME_LENGTH 24  // Tamaño en caracteres del frame de salida.

#define MAX_RX_DATA_SIZE 64                      // Tamaño del buffer de entrada.
#define MAX_TX_DATA_SIZE MAX_TX_FRAME_LENGTH * 2 // Tamaño máximo del buffer de salida, es el doble del de entrada porque cada caracter es un byte.
#define UART_CHAR_RX_TIME 200                    // Tiempo que se espera para que ingresen todos los datos en el buffer de la uart.

#define DEBUG true // Habilitar debug.
#define SERIAL_DEBUG \
  if (DEBUG)         \
  Serial

class UartDriver
{
public:
  // Estados de la máquina.
  enum CmdTransactionStatus
  {
    IDLE,
    SENDING,
    WAITING_RESP,
    RESP_READY
  };

  UartDriver(SoftwareSerial *port, const uint32_t &baudrate);

  /**
   * @brief Envía un comando al modem.
   *
   * @param buffer Comando a enviar.
   * @param addEndMessageChar Indica si se debe agregar un caracter de final de mensaje o no (0x1A).
   * @param length Si se especifica, la librería verificará que la longitud de la trama sea de, al menos length.
   */
  void send(const char *buffer, bool addEndMessageChar = false, const uint16_t &length = 0);

  /**
   * @brief Recibe la respuesta del modem.
   *
   * @param buffer Vector donde se recibe la respuesta.
   * @param matchOk Cadena de caracteres con la respuesta esperada por parte del modem.
   * @return Error::Code con el código de error resultante de la transacción.
   */
  Error::Code receive(char *buffer, const char *matchOk = nullptr);

  /**
   * @brief Estado de error de la máquina de estados.
   * 
   * @return Error::Code código de error. 
   */
  Error::Code errorStatus();

  /**
   * @brief Estado en el que se encuentra la máquina.
   * 
   * @return uint8_t código de estado.
   */
  uint8_t comStatus();

  /**
   * @brief Lleva el control de la máquina de estados. Se encarga de llamar a las otras funciones y evolucionar la máquina cuando 
   * las condiciones están dadas. Se debe llamar de forma permanente en el update de la clase madre para que se actualicen los estados.
   * 
   */
  void update();

  ~UartDriver() {}

private:
  uint32_t __baudrate;  // Baudrate del puerto serie.
  Error::Code __errorStatus;  // Handler para los códigos de errores.

  // Variables para el manejo de tiempos en los delays no bloqueantes.
  uint32_t __currT = 0;
  uint32_t __timeoutPrevT = 0;
  uint32_t __rxCharPrevT = 0;

  bool __dataReceivedFlag = false;    // Indicador de que se recibió un dato.
  bool __timeoutExecFlag = false;     // Flag que actualiza el tiempo anterior para que el contador de timeout comience a contar desde el instante en que pasa a alto.
  bool __endMessageCharFlag = false;  // Flag que indica si se debe agregar el caracter 0x1A de final de mensaje.

  uint16_t __respLength = 0;          // Longitud de la respuesta del modem esperada en caso de que la clase madre lo especifica.

  char __dataRXTX[MAX_TX_DATA_SIZE] = ""; // Buffer utilizado como entrada y salida.
  SoftwareSerial *__port;                 // Handler del puerto serie.

  /**
   * @brief Chequea constantemente si se debe caer en timeout.
   * 
   */
  void __timeoutCheck();

protected:
  uint8_t __transactStatus; // Estado actual de la máquina.

  /**
   * @brief Permite abrir el puerto serie.
   * 
   */
  void __portOpen();

  /**
   * @brief Cierra el puerto serie.
   * 
   */
  void __portClose();

  /**
   * @brief Resetea todas las variables del driver de UART.
   * 
   */
  void __uartDriverReset();
};

#endif
